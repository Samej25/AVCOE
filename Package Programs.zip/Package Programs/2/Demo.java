package abhi;  
public class Demo 
{  
 public void sum(int num1, int num2) 
 {  
    int result;  
    result = num1 + num2;  
    System.out.println("the sum of two numbers is:" + result);  
 }  
}  