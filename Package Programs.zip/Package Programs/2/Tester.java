import abhi.Demo;  
class Tester  
{  
 public static void main(String args[]) 
{  
  Demo obj = new Demo();  
  obj.sum(30, 50);  
 }  
}  